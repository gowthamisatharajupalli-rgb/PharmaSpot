window.$ = window.jQuery = window.require('jquery');
require('./assets/js/pos.js');
require('./assets/js/product-filter.js');
require('./assets/js/checkout.js');
require('print-js');