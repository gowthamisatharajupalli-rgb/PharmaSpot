/*app.config.js*/
let appConfig = {
	UPDATE_SERVER: "https://download.pharmaspot.patternsdigital.com",
	// about 
	COPYRIGHT_YEAR: "2022",
}

module.exports={appConfig}